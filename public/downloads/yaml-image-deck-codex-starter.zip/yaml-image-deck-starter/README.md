# YAML Image Deck｜Codex 練習素材包

這是本次教學整理的練習素材，不是原作者的官方發行版，也不是已完成的簡報。
主題：給小店老闆的 AI 社群貼文入門。8 頁，規劃 20 分鐘，plate 模式。

## 開始
將整個資料夾放到自己的 Mac，使用 Codex App 開啟此資料夾。先閱讀 prompt/stage-prompts.md，只貼階段 0 的提示詞；每個階段完成並檢查後才貼下一段。
不需要自行編輯 YAML。範例 YAML 是可參考的草稿，不代表你已核准，也沒有生成任何圖片。

## 檔案
- sources/course-source.md：本教學撰寫的虛構課程案例，沒有真實業績或促銷資料。
- prompt/brief.md：需求表。
- prompt/brand.md：視覺方向。
- prompt/outline.example.md：8 頁大綱草稿。
- prompt/spec.example.yaml：依原專案欄位建立的 8 頁規格草稿。
- prompt/stage-prompts.md：各階段提示詞。
- qa/EXAMPLE_VALIDATION.md：實際範例檢查結果與未驗證範圍。

## 使用原則
安裝原 Skill 前，先由 Codex 檢視來源檔案；優先使用專案內 .agents/skills/yaml-image-deck/。
沒有附原作者的 Skill、任何字型、圖片、PPTX 或已核准紀錄。
沒有代你安裝套件或修改你電腦上的專案。

prompt/spec.example.yaml 內的 output 都是預定輸出位置；design_system.style_reference 留空，不能當成已有樣張。
plate 的文字疊加座標並未預先實作；請在階段 3 依實際簡報工具補足。不要把範例當成一鍵生成器。

## 原始依據（查閱：2026-10-11）
- 專案：https://github.com/mathruffian-dot/yaml-image-deck
- Skill：https://github.com/mathruffian-dot/yaml-image-deck/blob/main/skills/yaml-image-deck/SKILL.md
- 規格：https://github.com/mathruffian-dot/yaml-image-deck/blob/main/skills/yaml-image-deck/references/schema.md
- 模板：https://github.com/mathruffian-dot/yaml-image-deck/blob/main/skills/yaml-image-deck/assets/spec-template.yaml
- Codex Skills：https://developers.openai.com/codex/skills/
- 圖像使用：https://learn.chatgpt.com/docs/image-generation

大綱、案例、分批數量、需求表及階段停點是本教學建議，不是原專案強制規格。
