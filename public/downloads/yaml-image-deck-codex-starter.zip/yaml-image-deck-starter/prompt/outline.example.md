# 8 頁大綱草稿
狀態：DRAFT／未經使用者核准。所有時間為本教學的安排建議。
| 頁 | 類型 | 核心訊息 | 版型 | 分鐘 |
|---|---|---|---|---|
| 1 | 封面 | 先說清楚，再讓 AI 寫 | `cover_hero` | 1 |
| 2 | 痛點 | 卡住的不是打字速度 | `case_scene_analysis` | 2 |
| 3 | 比較 | 指令清楚，草稿才有方向 | `comparison_split` | 3 |
| 4 | 流程 | 完成草稿之後還有核對 | `process_timeline` | 2 |
| 5 | 分類 | 開始前準備四種資訊 | `classification_grid` | 3 |
| 6 | 案例 | 完整示範只使用已知資料 | `case_scene_analysis` | 2 |
| 7 | 核對 | 人負責發布前的最後判斷 | `summary_three` | 2 |
| 8 | 練習 | 從一篇草稿開始練習 | `action_next_step` | 5 |

總計 20 分鐘。第 8 頁包含 3 分鐘實作與 2 分鐘說明或分享。
講者備註應包含 sources/course-source.md 的完整案例提示詞，不能把全文塞到投影片。
版型 variant 是本練習的描述標籤；原專案驗證器主要限制 layout.id，並非每個 variant 都有預製渲染器。
