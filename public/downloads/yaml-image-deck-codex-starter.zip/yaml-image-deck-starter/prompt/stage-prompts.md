# 各階段提示詞
每次只貼當前階段。範例檔案均為草稿；只有你實際檢視並表示同意後，才貼核准提示詞。

## 階段 0｜建立環境
```text
請只準備這個 YAML Image Deck 練習專案，不要生圖。
先回報目前工作區絕對路徑，確認是我開啟的練習資料夾，不操作其他專案。
檢查是否已有同名 yaml-image-deck Skill；有則讀取並回報路徑與來源，不重複安裝或覆蓋。
若未安裝，先檢視 https://github.com/mathruffian-dot/yaml-image-deck 的 README、Skill 與腳本，再將 skills/yaml-image-deck 安裝到本專案 .agents/skills/yaml-image-deck/，保留來源版本資訊。
檢查：內建生圖是否可呼叫、Python 3 與 PyYAML/Pillow、可建立及渲染 PPTX 的工具、Skill 指定圓體是否已安裝。檢查不等於實際生圖測試，請分別回報。
缺少 Python 套件可安裝於本專案 .venv；缺少系統軟體或字型先回報。不要自行啟用 API 計費。
建立 sources、prompt、slides/images、slides/previews、output、qa；已有檔案保持不覆蓋。
輸出 qa/environment.md。遇到無法完成的項目寫明，不宣稱已測試或已安裝。
```

## 階段 1｜整理內容
```text
請讀取 prompt/brief.md、prompt/brand.md 與 sources/，目前不要生圖。
先列出實際存在的素材，只讀與本次主題有關的內容。若有 PPT/PDF，整理時保留檔名與頁碼；不要只靠文字萃取判斷圖表內容。
將可使用資料、我的案例、待查證內容分開，寫入 prompt/content-notes.md。
虛構晨光咖啡案例只能使用來源明確提供的資訊，不添加價格、折扣、日期或成效。
資料衝突時列出差異；關鍵資訊不足時不要代填事實，先列待確認。
不要修改 sources/。完成後停在內容審查，不製作簡報。
```

## 階段 2｜建立大綱
```text
請依 prompt/brief.md 與已核對的內容，建立 8 頁、20 分鐘的教學大綱。
可參考 prompt/outline.example.md，但該檔案是草稿，不代表我已核准。
每頁列出：頁碼、目的、唯一核心訊息、精確上版文字、圖像構想、資料來源、講者備註、時間。
標題約 16 字內；一般頁盡量 3 個重點；4 格分類與4步流程依實際結構。
完整範例提示詞放講者備註或練習講義，不塞入圖片。
輸出 prompt/outline.md、prompt/speaker-notes.md。完成後停下，等我確認內容才進設計。
```

## 階段 3｜建立 YAML 與文字層
```text
使用 $yaml-image-deck，只做設計規格，不要生圖。
讀取此 Skill 的模板、schema.md、layout-library.md、prompting.md，以及已核准的 prompt/outline.md 和 prompt/brand.md。
可參考 prompt/spec.example.yaml，但請以核准的大綱為準建立 prompt/spec.yaml。
設定 plate、yaml_spec、sequential、golden_sample、16:9。每頁使用原專案支援的 layout.id；相同版型不要連續超過兩頁。
沒有真實核准樣張前，design_system.style_reference 保持空白，不假造路徑。
visible_text 是稍後疊加的原生文字，不准出現在生圖底圖中。
另建立 prompt/overlay-plan.yaml，定義每頁文字的頁碼、內容、x/y/w/h、明確單位、字型、字級、顏色及對齊。這是本專案的組裝規格，請說明實際簡報工具如何讀取；不要假稱原專案已內建完整 overlay 渲染器。
執行原 validate_spec.py，保存紀錄；缺字型先回報。完成後只展示設計摘要與待確認事項。
```

## 階段 4｜只生成黃金樣張
```text
使用 $yaml-image-deck，這次只製作第 3 頁，不生成其他頁。
讀取 prompt/spec.yaml、prompt/overlay-plan.yaml 和相關 Skill 規則。
先編譯並保存 prompt/image-prompts/page_03_v01.md：包含 16:9、安全範圍、左右比較布局、主體、文字預留區、共用配色與禁止事項。plate 模式不得生成任何文字、偽文字、標籤、Logo 或頁碼。
使用實際可用的內建生圖工具生成底圖，保存 slides/images/page_03_v01.png；若工具不可用就停止生圖步驟並回報，不改用程式插畫冒充。
依規格疊加原生可編輯文字，輸出 output/golden-sample_v01.pptx 及從該 PPTX 渲染的 slides/previews/page_03_v01.png。
檢查文字、留白、物件數量與16:9；不得拉伸圖片。如果環境不能渲染PPTX，明確標記未驗證。
讓我同時檢視無字底圖和含字完整頁，等待我核准。
```

## 階段 4B｜核准後鎖定
```text
我已檢視並核准第 3 頁 v01 的底圖與含字版面。請先確認這兩個實際檔案存在。
保留原始版本，將核准底圖另存 slides/images/page_03.png，並將 design_system.style_reference 指向這張真實存在的無字底圖。
在 qa/approval-log.md 記錄我這次的核准與檔案路徑。後續參考風格，不複製同一版型。
尚未核准或檔案不存在的內容，不得列為 APPROVED。先不要生成其他頁。
```

## 階段 5｜分批生成
```text
使用 $yaml-image-deck，沿用核准的 prompt/spec.yaml、文字層規格與第3頁黃金底圖。
先實際讀取參考圖片；這次只生成第4、5頁，一頁一次呼叫。
保持配色、材質與插畫語言，但使用各自核准的流程/分類版型。
每頁保存最終生圖提示詞、原始底圖與含原生文字的完整頁面預覽。記錄實際生成尺寸。
僅在不切掉內容的前提下裁切或補邊至16:9；禁止硬拉伸。物件數量或留白不合格就只重做該頁，每頁最多重試2次後回報。
不要改文字、原始素材或已核准頁。完成兩頁後停下供檢查。
等我確認試批通過後，再用同樣流程生成第1、2、6、7、8頁，不重做第3、4、5頁。
```

## 階段 6｜組裝與驗收
```text
請先確認每頁素材與文字是否已通過前一階段，不把缺頁當成完成。
執行 validate_spec.py 與 verify_images.py，原始命令、標準輸出與退出碼儲存於 qa/。
使用目前實際可用的簡報製作工具，組裝 output/ai-social-post_v01.pptx。
每頁是一張AI生成的無字底圖，加上原生可編輯標題、標籤、重點與頁碼；精確箭頭另用原生物件。不得把整張含字預覽貼進去冒充plate。
文字依核准大綱，附上講者備註與來源。保留組裝程式碼或可重跑指令。
重新渲染匯出的PPTX，逐頁檢視並生成 slides/previews/contact-sheet_v01.png，檢查缺字、換行、遮擋、安全區、頁數與順序。
qa/QA_REPORT.md 分開記錄：腳本結果、PPTX渲染檢查、人工檢查待辦。未執行的項目寫未驗證，不寫PASS。
交付PPTX、底圖、完整預覽、YAML、提示詞與檢查紀錄。不自行提交或推送Git。
```

## 階段 7｜局部修訂
```text
以 output/ai-social-post_v01.pptx 為基準建立v02，保留v01。
只把第3頁標題改為「先給資訊，再請 AI 寫」，其他文字和所有底圖不變，不呼叫生圖。
同步更新核准大綱、spec.yaml與文字層規格，再重建PPTX。
重新渲染第3頁，檢查換行與重疊；確認其他頁沒有非預期差異，將差異與檢查結果記錄qa/。
我在PowerPoint手動修改的文字若與YAML不一致，先列差異，不以舊YAML覆蓋。
```
